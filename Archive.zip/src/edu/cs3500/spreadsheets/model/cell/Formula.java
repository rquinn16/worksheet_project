package edu.cs3500.spreadsheets.model.cell;

/**
 * Interface representing the content found in a cell.
 */
public interface Formula extends Content {

}
